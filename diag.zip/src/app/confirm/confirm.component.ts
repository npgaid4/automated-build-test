import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { ConfirmControlService } from './confirm-control.service';
import { DialogType } from './confirm.service';

@Component({
  selector: 'app-confirm-ok',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit, AfterViewInit {
  @ViewChild('firstElment', { static: false }) fe: ElementRef; /* #firstElmentの要素 */

  title: string;
  message: string;
  kind: number;

  constructor(private _confirmControlService: ConfirmControlService) { }

  ngOnInit() {
    this.title = this._confirmControlService.title;
    this.message = this._confirmControlService.message;
    this.kind = this._confirmControlService.kind;
  }

  ngAfterViewInit() {
    if (this.kind !== 0) {
      /* 指定した要素にfocusを当てる */
      this.fe.nativeElement.focus();
    }
  }

  onClick(result: string): void {
    this._confirmControlService.close(result);
  }

  onKeyup(event: any): void {
    if (event.key !== undefined) {
      const key = event.key.toLowerCase();
      if (key === 'escape') {
        switch (this.kind) {
          case DialogType.PROGRESS:
            break;
          case DialogType.OK:
            this.onClick('OK');
            break;
          case DialogType.YES_NO_CANCEL:
            this.onClick('CANCEL');
            break;
          case DialogType.OK_CANCEL:
          default:
            this.onClick('NO');
            break;
        }
      } else if (key === 'enter') {
        switch (this.kind) {
          case DialogType.PROGRESS:
            break;
          case DialogType.OK:
          case DialogType.OK_CANCEL:
          case DialogType.YES_NO_CANCEL:
          default:
            this.onClick('OK');
            break;
        }
      }
    }
  }

}
