import { Injectable, Output, EventEmitter } from '@angular/core';
import { Overlay, OverlayRef, OverlayConfig } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';

import { ConfirmComponent } from './confirm.component';
import { ConfirmControlService } from './confirm-control.service';

@Injectable({
  providedIn: 'root',
})
export class ConfirmService {
  @Output() readonly confirmCloseEvent = new EventEmitter<ConfirmResult>();    /* ダイアログ終了時のイベント通知 */
  private _overlayRef: OverlayRef;                              /* ダイアログ表示用のオーバーレイ */
  private _componentPortal: ComponentPortal<ConfirmComponent>;  /* 表示するコンポーネント */
  private _sign: string;                                        /* 呼び出し元サイン */

  constructor(private _overlay: Overlay, private _dialogControlService: ConfirmControlService) {
    const scrollStrategy = this._overlay.scrollStrategies.block();
    const positionStrategy = this._overlay.position().global()
      .centerHorizontally().centerVertically();
    const config = new OverlayConfig({
      hasBackdrop: true, /* 背景半透明 */
      scrollStrategy,    /* 背景のスクロール禁止 */
      positionStrategy   /* 位置中央 */
    });

    this._overlayRef = this._overlay.create(config);
    this._componentPortal = new ComponentPortal(ConfirmComponent);
    this._dialogControlService.overlayRef = this._overlayRef;

    this._dialogControlService.confirmControlCloseEvent.subscribe(result => {
      const ret: ConfirmResult = new ConfirmResult();
      ret.result = result;
      ret.sign = this._sign;
      this.confirmCloseEvent.emit(ret);
    });

  }

  /**
   * show                  コンファームダイアログ/プログレスダイアログの表示
   * @param title          ダイアログのタイトル
   * @param message        メッセージ本文
   * @param sign           コールバックで処理の切り分けsign(keyword)
   * @param kind           ダイアログ種別(DialogType.Progress(0): プログレス, YES_NO_CANCEL(1): YES/NO/CANCEL, OK_CANCEL(2): OK/CANCEL, OK(3): OK)
   */
  show(title: string = '', message: string = '', sign: string = '', kind: DialogType = DialogType.OK): void {

    this._dialogControlService.title = title;
    this._dialogControlService.message = message;
    this._sign = sign;
    this._dialogControlService.kind = kind;

    this._overlayRef.attach(this._componentPortal);
  }
  /**
   * forcedTermination  show()で表示しているダイアログをダイアログ以外で強制終了させる
   */
  forcedTermination(): void {
    this._dialogControlService.close('OK');
  }

}

export class ConfirmResult {
  result: string;
  sign: string;
}

export enum DialogType {
  PROGRESS = 0,
  YES_NO_CANCEL,
  OK_CANCEL,
  OK
}
