import { Injectable, Output, EventEmitter } from '@angular/core';
import { OverlayRef } from '@angular/cdk/overlay';

@Injectable({
  providedIn: 'root',
})
export class ConfirmControlService {
  @Output() readonly confirmControlCloseEvent = new EventEmitter<string>();
  private _overlayRef: OverlayRef;
  title: string;
  message: string;
  kind: number;

  set overlayRef( overlayRef: OverlayRef ) {
    this._overlayRef = overlayRef;
  }

  close(result: string): void {
    this._overlayRef.detach();
    this.confirmControlCloseEvent.emit(result);
  }
}
