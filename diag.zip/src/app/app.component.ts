import { Component } from '@angular/core';
import { ConfirmService, DialogType } from './confirm/confirm.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dialogSample';
  // tslint:disable-next-line:variable-name
  constructor(private _confirmService: ConfirmService) {}
  dialog(): void {
    this._confirmService.show('REST API', '編集するファイルを選択してください');
    console.log('click');
  }
}
