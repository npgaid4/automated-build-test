package com.gmail.etc.npg;

import com.gmail.etc.npg.bacmode.key.BacModeKeySeed;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class BacMode {


    public static void main(String[] args) {
        String keySeed;
        BacModeKeySeed seed = new BacModeKeySeed("ab12345", "20000203", "20211031");
        keySeed = seed.makeKeySeed();
        if (keySeed.startsWith("Error")) {
            System.out.println(keySeed);
        }else{
            System.out.println("Key is " + keySeed);
        }
    }

}
