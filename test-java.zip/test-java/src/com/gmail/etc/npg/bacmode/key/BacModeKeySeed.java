package com.gmail.etc.npg.bacmode.key;

import java.util.Calendar;


public class BacModeKeySeed {
    final String ERRORWORD = "Error: ";
    final int MAXLENGTH = 9;
    final String APPENDCHAR = "<";
    final String CR = "\n";

    private String ppNumber; // パスポート番号
    private String birthDay; //　生年月日
    private String expireDay; //　有効期限

    public BacModeKeySeed(final String ppNum,final String birthDay,final String expireDay) {
        this.ppNumber = ppNum;
        this.birthDay = birthDay;
        this.expireDay = expireDay;
    }

    private String birthdayValidationCheck(final String birthday) {

        String result = "";

        Calendar calendar = Calendar.getInstance();
        int nowYear = calendar.get(Calendar.YEAR);
        int nowMonth = calendar.get(Calendar.MONTH) + 1; //月は０始まり
        int nowDay = calendar.get(Calendar.DATE);

        int bDateYear = Integer.parseInt(birthday.substring(0, 4));
        int bDateMonth = Integer.parseInt(birthday.substring(4, 6));
        int bDateDay = Integer.parseInt(birthday.substring(6, 8));

        // 生年月日の月が1-12の値になっているか確認
        if (bDateMonth < 1 || bDateMonth > 12) {
            if (result.startsWith(ERRORWORD)) {
                result = result + "生年月日の月設定が1月から12月になっていません。";
            } else {
                result = ERRORWORD;
                result = result + "生年月日の月設定が1月から12月になっていません。";
            }
        }

        //  生年月日の日が1-31の値になっているか確認
        if (bDateMonth == 2 || bDateMonth == 4 || bDateMonth == 6 || bDateMonth == 9 || bDateMonth == 11) {
            if (bDateDay < 1 || bDateDay > 30) {
                if (result.startsWith(ERRORWORD)) {
                    result = result + "生年月日の日設定が1日から30日になっていません。";
                } else {
                    result = ERRORWORD;
                    result = result + "生年月日の日設定が1日から30日になっていません。";
                }
            }
        } else {
            if (bDateDay < 1 || bDateDay > 31) {
                if (result.startsWith(ERRORWORD)) {
                    result = result + "生年月日の日設定が1日から31日になっていません。";
                } else {
                    result = ERRORWORD;
                    result = result + "生年月日の日設定が1日から31日になっていません。";
                }
            }
        }

        if (result.isBlank()) {
            // 生年月日の未来になってないか確認
            if (bDateYear > nowYear) {
                if (result.startsWith(ERRORWORD)) {
                    result = result + "生年月日が未来の日付になっています。";
                } else {
                    result = ERRORWORD;
                    result = result + "生年月日が未来の日付になっています。";
                }
            } else if (bDateYear == nowYear) {
                if (bDateMonth > nowMonth) {
                    if (result.startsWith(ERRORWORD)) {
                        result = result + "生年月日が未来の日付になっています。";
                    } else {
                        result = ERRORWORD;
                        result = result + "生年月日が未来の日付になっています。";
                    }
                } else if (bDateDay > nowDay) {
                    if (result.startsWith(ERRORWORD)) {
                        result = result + "生年月日が未来の日付になっています。";
                    } else {
                        result = ERRORWORD;
                        result = result + "生年月日が未来の日付になっています。";
                    }
                }
            }
        }
        // No Error
        if (result.isBlank()) {
            result = birthday.substring(2, 8);
        }
        return result;
    }

    private String expirationdateValidationCheck(final String expirationdate) {

        String result = "";

        Calendar calendar = Calendar.getInstance();
        int nowYear = calendar.get(Calendar.YEAR);
        int nowMonth = calendar.get(Calendar.MONTH) + 1; //月は０始まり
        int nowDay = calendar.get(Calendar.DATE);

        int eDateYear = Integer.parseInt(expirationdate.substring(0, 4));
        int eDateMonth = Integer.parseInt(expirationdate.substring(4, 6));
        int eDateDay = Integer.parseInt(expirationdate.substring(6, 8));


        // 有効期限の月が1-12の値になっているか確認
        if (eDateMonth < 1 || eDateMonth > 12) {
            if (result.startsWith(ERRORWORD)) {
                result = result + "有効期限の月設定が1月から12月になっていません。";
            } else {
                result = ERRORWORD;
                result = result + "有効期限の月設定が1月から12月になっていません。";
            }
        }

        //  有効期限の日が1-31の値になっているか確認
        if (eDateMonth == 2 || eDateMonth == 4 || eDateMonth == 6 || eDateMonth == 9 || eDateMonth == 11) {
            if (eDateDay < 1 || eDateDay > 30) {
                if (result.startsWith(ERRORWORD)) {
                    result = result + "有効期限の日設定が1日から30日になっていません。";
                } else {
                    result = ERRORWORD;
                    result = result + "有効期限の日設定が1日から30日になっていません。";
                }
            }
        } else {
            if (eDateDay < 1 || eDateDay > 31) {
                if (result.startsWith(ERRORWORD)) {
                    result = result + "有効期限の日設定が1日から31日になっていません。";
                } else {
                    result = ERRORWORD;
                    result = result + "有効期限の日設定が1日から31日になっていません。";
                }
            }
        }


        // No Error
        if (result.isBlank()) {
            result = expirationdate.substring(2, 8);
        }
        return result;
    }

    private String ppNumberValidationCheck(final String ppNumber){
        String result = "";

        StringBuilder validPPNum = new StringBuilder(ppNumber);
        int notEnough = MAXLENGTH - validPPNum.length();

        if(notEnough > 0){
            for(int i = 0;i < notEnough;i++) {
                validPPNum.append(APPENDCHAR);
                result = validPPNum.toString();
            }
        }else if (notEnough <= -1){
            result = (validPPNum.substring(0,9)).toString();
        }else{
            result = validPPNum.toString();
        }
        return result;
    }

    /**
     * makeKeySeed
     * パスポート番号、生年月日、有効期限から共通鍵の種を作成します
     * パスポート番号、生年月日、有効期限はコンストラクタで設定します
     *
     * @return　keySeed: 共通鍵の種
     */
    public String makeKeySeed(){
        String keySeed = "";

        String ppNumberResult = ppNumberValidationCheck(this.ppNumber);
        String birthDayResult = birthdayValidationCheck(this.birthDay);
        String expireDayResult = expirationdateValidationCheck(this.expireDay);

        if(birthDayResult.startsWith(ERRORWORD)){
            keySeed = keySeed + birthDayResult;
        }
        if(expireDayResult.startsWith(ERRORWORD)){
            if(!keySeed.isBlank()){
                keySeed = keySeed + CR;
            }
            keySeed = keySeed + expireDayResult;
        }
        if(keySeed.isBlank()){
            keySeed = ppNumberResult + birthDayResult + expireDayResult;
            return keySeed;
        }else{
            return keySeed;
        }
    }
}
