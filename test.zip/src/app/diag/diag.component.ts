import {Component, Inject, OnInit, Optional} from '@angular/core';
import {AppOverlayRef} from '../diag-ref.service';
import {APP_OVERLAY_DATA} from '../diag-start.service';
import {DiagHttpService} from '../diag-http.service';
import {PrefsData, Pref} from '../diag-http.service';

@Component({
  selector: 'app-diag',
  templateUrl: './diag.component.html',
  styleUrls: ['./diag.component.css']
})

export class DiagComponent implements OnInit {

 /* prefs = [
    {id: '01', name: '北海道'},
    {id: '02', name: '東京'},
    {id: '03', name: '大阪'},
    {id: '04', name: '京都'},
    {id: '05', name: '兵庫'},
  ];
*/

  prefs: Pref[];
  private pref: PrefsData;

  constructor(private diagHttp: DiagHttpService, readonly overlayRef: AppOverlayRef<DiagComponent>,
              @Inject(APP_OVERLAY_DATA) @Optional() readonly data?: any) {
    this.prefs = this.diagHttp.getPrefs();
  }

  ngOnInit(): void {

  }

  getP(){
    console.log('検索');
  }

  close() {
    this.diagHttp.closePrefs();
    this.overlayRef.close(this.prefs);
  }

}

