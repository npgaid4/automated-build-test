import { TestBed } from '@angular/core/testing';

import { DiagHttpService } from './diag-http.service';

describe('DiagHttpService', () => {
  let service: DiagHttpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DiagHttpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
