import {Injectable} from '@angular/core';
import {HttpClient, HttpEvent, HttpHeaders} from '@angular/common/http';
import {Observable, Subscription} from 'rxjs';

export class Pref{
  prefCode: number;
  prefName: string;
}

export class PrefsData {
  message = '';
  result: Pref[] = [];
}

@Injectable({
  providedIn: 'root'
})
export class DiagHttpService {

  private subp: Subscription;
  // private prefsData: PrefsData;
  private prefsData: any;
  private prefs: any;

  private httpOptins: any = {
    headers: new HttpHeaders({
      'X-API-KEY': 'fyN5S22wblmLwizzy57Byplt7JSJo65IwNXaALVt'
    }),
  };

  private server = `https://opendata.resas-portal.go.jp/api/v1/prefectures`;

  constructor(private http: HttpClient) {
    this.subp = this.http.get<PrefsData>(this.server, this.httpOptins).subscribe((value) => {
      this.prefsData = value;
      this.prefs = this.prefsData.result;
      console.log('diag-http constructor');
    });
  }

  getPrefs() {
    return this.prefs;
  }

  closePrefs(){
    this.subp.unsubscribe();
  }

}
