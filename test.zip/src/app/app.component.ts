import { Component } from '@angular/core';
import {AppOverlayService} from './diag-start.service';
import { DiagComponent } from './diag/diag.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'test';
  result: any;

  // tslint:disable-next-line:variable-name
  constructor(private readonly _overlay: AppOverlayService) {}

  onClick(){
    const ref = this._overlay.show(DiagComponent, {});
    ref.closed$.subscribe(v => this.result = v);
  }
}
