import { TestBed } from '@angular/core/testing';

import { DiagStartService } from './diag-start.service';

describe('DiagStartService', () => {
  let service: DiagStartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DiagStartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
