import { TestBed } from '@angular/core/testing';

import { DiagRefService } from './diag-ref.service';

describe('DiagRefService', () => {
  let service: DiagRefService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DiagRefService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
